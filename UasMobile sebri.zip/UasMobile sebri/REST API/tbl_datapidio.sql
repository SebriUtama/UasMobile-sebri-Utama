INSERT INTO `tbl_datapidio` VALUES ('001', 'Rubuusanah Surabya', '2022-01-01', 'surabya');
INSERT INTO `tbl_datapidio` VALUES ('002', 'Rubuusanah Lamongan', '2021-12-14', 'Lamongan');
INSERT INTO `tbl_datapidio` VALUES ('003', 'Rubuusanah Kediri', '2022-01-16', 'Kediri');
